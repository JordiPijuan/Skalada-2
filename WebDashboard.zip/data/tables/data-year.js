$(document).ready(function () {

	var dataYear = [
	  {
		"Year": 2020,
		"Blocked": 634,
		"Total": 428398,
		"Sended": 425134,
		"Error": 3264,
		"SendOk": 99.24,
		"SendKo": 0.76,
		"NewExpedient": 32005,
		"CloseExpedient": 27553
	  },
	  {
		"Year": 2021,
		"Total": 0,
		"SendOk": 0,
		"SendKo": 0
	  }
	];

});	
