$(document).ready(function () {

	var closurelabels = ['CE1','CE2','CE4','CE5','CE7','CE8','CE9','CE10'];
	var closuredata = [651,2866,2655,907,15831,353,5158,1088];
	var closurebackgroundcolors = ["#3e95cd", "#8e5ea2","#3cba9f","#e8c3b9","#c45850","#007bff","#e83e8c","#fd7e14"];
	
	var subclosureslabels = ['CE1','CE21','CE22','CE23','CE24','CE41','CE42','CE51','CE52','CE53','CE54','CE55','CE71','CE72','CE73','CE8 ','CE91','CE92','CE94','CE95','CE101','CE102','CE103'];
	var subclosuresdata = [651,985,1508,7,366,610,2045,735,14,3,36,119,409,15172,250,353,422,27,4544,165,428,289,371];
	var subclosurebackgroundcolors = ["#3e95cd", "#8e5ea2","#3cba9f","#e8c3b9","#c45850","#007bff","#e83e8c","#fd7e14","#3e95cd", "#8e5ea2","#3cba9f","#e8c3b9","#c45850","#007bff","#e83e8c","#fd7e14","#3e95cd", "#8e5ea2","#3cba9f","#e8c3b9","#c45850","#007bff","#e83e8c"];
	
});	
